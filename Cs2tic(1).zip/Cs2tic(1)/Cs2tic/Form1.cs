﻿//////////////////////////////////////////////////
/// Cynthia Gu, Tin Tin Chien
/// TINFO 200 A - C# Programming
/// 2-10-2023
//////////////////////////////////////////////////
/// Tic Tac Toe Game Player vs AI
/// A programed game of Tic Tac Toe where the player
/// plays against the AI.



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

///////////////////////////////////////////
//Date          Developer      Description 
//2023-02-06     Cs2tic 30      Initial creation 
//2023-02-07     Cs2tic 30      Created another version (1/4)
//2023-02-08     Cs2tic 30      Created another version (2/4)
//2023-02-09     Cs2tic 30      Created another version (3/4)
//2023-02-10     Cs2tic 30      Created another version (4/4)
//2023-02-10     Cs2tic 30      Initial testing 
//2023-02-11     Cs2tic 30      Put randomization on the X's and O's 
namespace Cs2tic
{
    // This is a Tic Tac Toe game program
    public partial class Form1 : Form
    {
        // These enumerators decide these objects 
        // are the items that would be display onto 
        // the board
        public enum Player
        {
            X, O
        }

        // This declares most of the variables
        Player currentPlayer;
        Random random = new Random();
        Random rng = new Random();
        List<Button> buttons;
        static int turnCount = 0;
        static bool gameEnd = false;
        private object button;
        static bool xPlayer1 = false;
        static bool oPlayer1 = false;
        static bool xPlayer2 = false;
        static bool oPlayer2 = false;

        // This would start the Tic Tac Toe game 
        // Would start a new game
        public Form1()
        {
            InitializeComponent();
            NewGame();
        }


        // New game resets current game and starts a new game
        // Decides if player or AI goes first
        private void NewGame(object sender, EventArgs e)
        {
            NewGame();
            textBox1.Clear();
            textBox2.Clear();
            turnCount = 0;
            gameEnd = false;

            var t = 0;
                t = rng.Next(1, 3);
                if (t == 1)
                {

                   
                    xPlayer1 = true;
                    
                   
                    oPlayer2 = true;
                    
                    aiMove(null, EventArgs.Empty);
                }
                else if (t == 2)
                {

                   
                    xPlayer2 = true;
                    
                    aiMove(null, EventArgs.Empty);

                  
                    oPlayer2 = true;
                    
                }


            

        }

        // User's turn in game
        // Assigns turn and X symbol to player
        // Once player makes their playing move
        // assign next turn to AI
        // After each turn, check game to see if 
        // there is a win.
        // Apply win and draw.
        private void PlayerClickBtn(object sender, EventArgs e)
        {
            if (gameEnd != true)

            {

                if (xPlayer1 == true)
                {
                    currentPlayer = Player.X;
                }
                else if (oPlayer1 == true)
                {
                    currentPlayer = Player.O; 
                }
                var button = (Button)sender;
                button.Text = currentPlayer.ToString();
                button.Enabled = false;
                buttons.Remove(button);
                CheckGame();

                if (gameEnd == false)
                {
                    aiTimer.Start();
                    turnCount++;

                    if (turnCount == 9)
                    {
                        aiTimer.Stop();
                        textBox1.Text = "Draw";
                        textBox2.Text = "Draw";

                    }
                }
            }
        }

        // Assigns AI turn after a player makes a turn
        // Check game for win and draw
        private void aiMove(object sender, EventArgs e)
        {

            if (buttons.Count > 0)
            {
                int index = random.Next(buttons.Count);
                buttons[index].Enabled = false;
                if(oPlayer2 == true)
                {
                    currentPlayer = Player.O;
                }
                else if (xPlayer2 == true)
                {
                    currentPlayer = Player.X;
                }
                buttons[index].Text = currentPlayer.ToString();
                buttons.RemoveAt(index);
                CheckGame();
                aiTimer.Stop();
                turnCount++;
            }
            else if (turnCount == 9)
            {
                aiTimer.Stop();
                textBox1.Text = "Draw";
                textBox2.Text = "Draw";
            }
        }

      

        // Clear all buttons for new game
        private void NewGame()
        {
            buttons = new List<Button> { button1, button2, button3, button4, button5,
                                         button6, button7, button8, button9 };
            foreach (Button button in buttons)
            {
                button.Enabled = true;
                button.Text = " ";
            }
        }

        // Exit the application
        private void ExitGame(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Checks all possible methods for win base
        // on player and AI moves
        // Declares winner and end games
        private void CheckGame()
        {
            disableBtns(true);

            if (button1.Text == "X" && button2.Text == "X" && button3.Text == "X"
                || button4.Text == "X" && button5.Text == "X" && button6.Text == "X"
                || button7.Text == "X" && button8.Text == "X" && button9.Text == "X"
                || button1.Text == "X" && button4.Text == "X" && button7.Text == "X"
                || button2.Text == "X" && button5.Text == "X" && button8.Text == "X"
                || button3.Text == "X" && button6.Text == "X" && button9.Text == "X"
                || button1.Text == "X" && button5.Text == "X" && button9.Text == "X"
                || button3.Text == "X" && button5.Text == "X" && button7.Text == "X")
            {

                gameEnd = true;

                aiTimer.Stop();
                if (xPlayer1 == true)
                {
                    textBox1.Text = "Player Wins!";
                }
                else if (xPlayer2 == true)
                {
                    textBox2.Text = "AI Wins!";
                }
                

            }
            else if (button1.Text == "O" && button2.Text == "O" && button3.Text == "O"
                || button4.Text == "O" && button5.Text == "O" && button6.Text == "O"
                || button7.Text == "O" && button8.Text == "O" && button9.Text == "O"
                || button1.Text == "O" && button4.Text == "O" && button7.Text == "O"
                || button2.Text == "O" && button5.Text == "O" && button8.Text == "O"
                || button3.Text == "O" && button6.Text == "O" && button9.Text == "O"
                || button1.Text == "O" && button5.Text == "O" && button9.Text == "O"
                || button3.Text == "O" && button5.Text == "O" && button7.Text == "O")
            {
                gameEnd = true;
                aiTimer.Stop();

                if (oPlayer1 == true)
                {
                    textBox1.Text = "Player Wins!";
                }
                else if (oPlayer2 == true)
                {
                    textBox2.Text = "AI Wins!";
                }
                


            }
            else if (turnCount == 9)
            {
                gameEnd = true;
                aiTimer.Stop();
                textBox1.Text = "Draw";
                textBox2.Text = "Draw";

            }
        }

        // disable buttons after a move has been made
        private void disableBtns(bool sensitive)
        {

            foreach (Button button in buttons)
            {
                button.Enabled = sensitive;
            }
        }

        private void XPlayer1(bool display)
        {
            var t = 0;
            for (int i = 1; i < 1; i++) 
            {
                t = rng.Next(1, 2);
            }

        }

    }
}

