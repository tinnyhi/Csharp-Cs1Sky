﻿///////////////////////////////
// Tin Tin Chien, Cynthia Gu
// TNFO-200 A - C# Program 
// 2023-02-26 
///////////////////////////////////
// This is an Employee Database
// Where the user can find, create, update, delete, print and quit from the data base


using System;

namespace Cs3emp
{
    public class BasePlusCommissionEmployee : CommissionEmployee
    {
        private decimal baseSalary;

        public BasePlusCommissionEmployee (string firstName, string lastName, 
                string socialSecurityNumber, string emailAddress,
                decimal grossSales, decimal commissionRate, decimal baseSalary)
                : base(firstName, lastName, socialSecurityNumber, emailAddress, 
                      grossSales, commissionRate)
        {
            BaseSalary = baseSalary;
        }

        // property that gets and sets 
        // BasePlusCommissionEmployee's base salary
        public decimal BaseSalary
        {
            get
            {
                return baseSalary;
            }
            set
            {
                if (value < 0) // validation
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
                       value, $"{nameof(BaseSalary)} must be >= 0");
                }

                baseSalary = value;
            }
        }

     


        // calculate earnings
        public override decimal Earnings() => BaseSalary + base.Earnings();

        // return string representation of BasePlusCommissionEmployee
        public override string ToString()
        {
            return base.ToString() + $"\nBase Salary: {BaseSalary:C}";
        }



    }
}