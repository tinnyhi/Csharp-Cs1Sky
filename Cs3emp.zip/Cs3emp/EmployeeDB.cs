﻿///////////////////////////////
// Tin Tin Chien, Cynthia Gu
// TNFO-200 A - C# Program 
// 2023-02-26 
///////////////////////////////////
// This is an Employee Database
// Where the user can find, create, update, delete, print and quit from the data base


using System;
using System.Collections.Generic;
using System.Dynamic;
using System.IO;

namespace Cs3emp
{
     class EmployeeDB
    {
        // global boolean switch for all test code
        public const bool _DEBUG_TEST_ONLY_ = false;

        // storage container while the db app is running 
        private List<Employee> employees = new List<Employee>();

        public EmployeeDB()
        {
           // if (_DEBUG_TEST_ONLY_) TestMain();

            ReadDataFromInputFile();
        }

        private const string _EMPLOYEE_DATA_INPUTFILE_ = "_EMPLOYEE_DATA_INPUTFILE_.txt";
        private const string _EMPLOYEE_DATA_OUTPUTFILE_ = "_EMPLOYEE_DATA_OUTPUTFILE_.txt";

        private void ReadDataFromInputFile()
        {
            // 1 - create a file object and connect it to the actual file on disk
            StreamReader inFile = new StreamReader(_EMPLOYEE_DATA_INPUTFILE_);

            string employeeType;

            // 2 - use the file object
            while ((employeeType = inFile.ReadLine()) != null) 
            {
                string first = inFile.ReadLine();
                string last = inFile.ReadLine();
                string ssn = inFile.ReadLine();
                string email = inFile.ReadLine();

                // have to know what we're reading
                if(employeeType == "EmpDB.Salaried")
                {
                    decimal salary = decimal.Parse(inFile.ReadLine());

                    employees.Add(new SalariedEmployee(first, last, ssn, email, salary));
                }
                else if (employeeType == "EmpDB.Hourly")
                {
                    decimal hourly = decimal.Parse(inFile.ReadLine());
                    decimal wage = decimal.Parse(inFile.ReadLine());

                    employees.Add(new HourlyEmployee(first, last, ssn, email, wage, hourly));

                }
                else if (employeeType == "EmpDB.Commission")
                {
                    decimal sales = decimal.Parse(inFile.ReadLine());
                    decimal rates = decimal.Parse(inFile.ReadLine());

                    employees.Add(new CommissionEmployee(first, last, ssn, email, sales, rates));
                }
                else if (employeeType == "EmpDB.BasePlusCommission")
                {
                    decimal sales = decimal.Parse(inFile.ReadLine());
                    decimal rates = decimal.Parse(inFile.ReadLine());
                    decimal bsalary = decimal.Parse(inFile.ReadLine());

                    employees.Add(new BasePlusCommissionEmployee(first, last, ssn, email, sales, rates, bsalary));
                }
                else
                {
                    Console.WriteLine("ERROR: not a valid employee type.");
                }
            }

            //3 - close the resource 
            inFile.Close();
            Console.WriteLine("Reading the input file was completed...\n");

        }

        public void GoDatabase()
        {
            string email = string.Empty;

            while(true)
            {
                DisplayMainMenu();

                char selection = GetUserInput();

                // CRUD operations - create, read, update, delete
                switch (selection)
                {
                    case 'F':
                    case 'f':
                        FindEmployeeRecord(out email);
                        break;
                    case 'C':
                    case 'c':
                        CreateEmployeeRecord();
                        break;
                    case 'U':
                    case 'u':
                        ModifyEmployeeRecord();
                        break;
                    case 'D':
                    case 'd':
                        DeleteEmployeeRecord(out email);
                        break;
                    case 'P':
                    case 'p':
                        PrintAllRecords();
                        break;
                    case 'X':
                    case 'x':
                    case 'Q':
                    case 'q':
                        QuitDatabaseAppAndSave();
                        break;
                    default:
                        Console.WriteLine("ERROR: " +
                            "This action is not recognized in the database.");
                        break;
                }

            }
        }

        private void DeleteEmployeeRecord(out string email)
        {
            Employee emp = FindEmployeeRecord(out email);
            
            if (emp != null)
            {
                Console.WriteLine($"Are you sure you want to remove student {emp.FirstName} {emp.LastName} (Y/N)?");
                string selection = Console.ReadLine();
                if (selection == "Y" || selection == "y")
                {
                    Console.WriteLine("******REMOVING EMPLOYEE FROM RECORD******");
                    // delete student from list
                    employees.Remove(emp);
                }
                else
                {
                    Console.WriteLine("DOES NOT RECONGIZE INPUT!!");
                }

            }
        }

        private void CreateEmployeeRecord()
        {
            Console.Write("\nEnter first name of employee:");
            string firstName = Console.ReadLine();

            Console.Write("\nEnter last name of employee:");
            string lastName = Console.ReadLine();

            Console.Write("\nEnter social security number of employee:");
            string ssn = Console.ReadLine();

            Console.Write("\nEnter email of employee:");
            string email = Console.ReadLine();

            Console.WriteLine("Is this employee [S]alaried, [H]ourly, [C]ommission, or [B]asePlusCommission");
            string selection = Console.ReadLine();
            if (selection == "S" || selection == "s")
            {
                Console.WriteLine("\nENTER in the weekly Salary: ");
                decimal salary = decimal.Parse(Console.ReadLine());

                SalariedEmployee salaried = new SalariedEmployee(firstName, lastName, ssn, email, salary);
                employees.Add(salaried);
            }
            else if (selection == "H" || selection == "h")
            {
                Console.WriteLine("\nENTER in the wage: ");
                decimal wage = decimal.Parse(Console.ReadLine());

                Console.WriteLine("\nENTER in the amount of hours: ");
                decimal hours = decimal.Parse(Console.ReadLine());

                HourlyEmployee hourly = new HourlyEmployee(firstName, lastName, ssn, email, wage, hours);
                employees.Add(hourly);
            }
            else if (selection == "C" || selection == "C")
            {
                Console.WriteLine("\nENTER in the gross sales: ");
                decimal grossSales = decimal.Parse(Console.ReadLine());

                Console.WriteLine("\nENTER in the percentage rate: ");
                decimal rates = decimal.Parse(Console.ReadLine());

                CommissionEmployee commission = new CommissionEmployee(firstName, lastName, ssn, email, grossSales, rates);
                employees.Add(commission);
            }
            else if (selection == "B" || selection == "b")
            {
                Console.WriteLine("\nENTER in the gross sales: ");
                decimal grossSales = decimal.Parse(Console.ReadLine());

                Console.WriteLine("\nENTER in the percentage rate: ");
                decimal rates = decimal.Parse(Console.ReadLine());

                Console.WriteLine("\nENTER in the base salary: ");
                decimal baseSalary = decimal.Parse(Console.ReadLine());

                BasePlusCommissionEmployee basePlusCommission = new BasePlusCommissionEmployee(firstName, lastName, ssn, email, grossSales, rates, baseSalary);
                employees.Add(basePlusCommission);

            }

        }

        private void ModifyEmployeeRecord()
        {
            string email = string.Empty;
            Employee emp = FindEmployeeRecord(out email);

            if (emp != null)
            {
                ModifyEmployee(emp);
            }
            else
            {
                Console.WriteLine($"****** RECORD NOT FOUND.\n Can't edit record for user {email}");
            }
        }

        private void ModifyEmployee(Employee emp)
        {
            string employeeType = emp.GetType().Name;
            Console.WriteLine(emp.ToString());
            Console.WriteLine($"Editing employee of type: {employeeType}");

            ModifyEmployeeMenu();
            char selection = GetUserInput();
            if(employeeType == "Salaried")
            {
                SalariedEmployee salaried = emp as SalariedEmployee;
                switch (selection)
                {
                    case 'P':
                    case 'p':
                        Console.WriteLine("\nENTER new pay/salary: ");
                        salaried.WeeklySalary = decimal.Parse(Console.ReadLine());
                        break;
                }
            }
            else if(employeeType == "Hourly")
            {
                HourlyEmployee hourly = emp as HourlyEmployee;
                switch(selection) 
                {
                    case 'W':
                    case 'w':
                        Console.WriteLine("\nENTER new wage: ");
                        hourly.Wage = decimal.Parse(Console.ReadLine());
                        break;
                    case 'H':
                    case 'h':
                        Console.WriteLine("\nENTER new hours: ");
                        hourly.Hours= decimal.Parse(Console.ReadLine());
                        break;
                }
            }
            else if(employeeType == "Commission")
            {
                CommissionEmployee commission = emp as CommissionEmployee;
                switch (selection)
                {
                    case 'G':
                    case 'g':
                        Console.WriteLine("\nENTER new gross sales: ");
                        commission.GrossSales = decimal.Parse(Console.ReadLine());
                        break;
                    case 'R':
                    case 'r':
                        Console.WriteLine("\nENTER new rate: ");
                        commission.CommissionRate = decimal.Parse(Console.ReadLine());
                        break;
                   
                }
            }
            else if(employeeType == "BasePlusCommission")
            {
                BasePlusCommissionEmployee basepcom = emp as BasePlusCommissionEmployee;
                switch (selection)
                {
                    case 'G':
                    case 'g':
                        Console.WriteLine("\nENTER new gross sales: ");
                        basepcom.GrossSales = decimal.Parse(Console.ReadLine());
                        break;
                    case 'R':
                    case 'r':
                        Console.WriteLine("\nENTER new rate: ");
                        basepcom.CommissionRate = decimal.Parse(Console.ReadLine());
                        break;
                    case 'B':
                    case 'b':
                        Console.WriteLine("\nENTER new base salary: ");
                        basepcom.BaseSalary = decimal.Parse(Console.ReadLine());
                        break;
                }
            }
        }

        private void ModifyEmployeeMenu()
        {
            Console.Write(@"
            *******************************************
            ********** Edit Employee Menu *************
            *******************************************
            [F]irst name 
            [L]ast name
            [S]ocial Secruity Number
            [P]ay/Salary             (Salaried)
            [W]age                   (Hourly)
            [H]ours                  (Hourly)
            [G]ross Sales            (Base & Commission)
            [R]ates                  (Base & Commission)
            [B]ase Salary            (Base) 
            **Email Address can never modified. See admin for details. 
            ENTER edit menu selection: 
            "); ;
        }

        private Employee FindEmployeeRecord(out string email)
        {
            // ask the user for that value 
            Console.Write("\nENTER email of employee to search: ");
            email = Console.ReadLine(); //assign a value 

            // take the value and search the list 
            // check to see if it matches 
            foreach (var emp in employees)
            {
                if (email == emp.EmailAddress)
                {
                    Console.WriteLine($"FOUND email address {emp.EmailAddress}");
                    return emp;
                }
            }

            // after going thru and not finding anything 
            Console.WriteLine($"{email} NOT FOUND!!");
            return null;
        }

        private void PrintAllRecords()
        {
            Console.WriteLine("\n***** Current roster of employee records *****");
            foreach (Employee emp in employees)
            {
                Console.WriteLine(emp);
            }
        }

        private void QuitDatabaseAppAndSave()
        {
            WriteDataToOutputFile();
            Environment.Exit(0);
        }

     
        private void WriteDataToOutputFile()
        {
            // make the file object and connect it to an actual file on disk
            StreamWriter outFile = new StreamWriter(_EMPLOYEE_DATA_OUTPUTFILE_);

            // use the object
            Console.WriteLine("\n**** Current contents of Employee database ****");
            foreach (Employee emp in employees)
            {
                // for now, echo the output to the shell for testing
                outFile.WriteLine(emp.ToStringForDataFile());
                Console.WriteLine(emp.ToStringForDataFile());
            }

            // close the file object
            outFile.Close();

        }

        private char GetUserInput()
        {
            ConsoleKeyInfo keyPressed = Console.ReadKey();
            return keyPressed.KeyChar;
        }

        private void DisplayMainMenu()
        {
            Console.WriteLine(@"
            ***********************************************
            *********** Database App Main Menu ************
            ***********************************************
            [F]ind employee record 
            [C]reate a new record
            [U]pdate, modify, or edit an existing record
            [D]elete a record permanently from the database
            [P]rint all records in the database
            [Q]uit the database after saving all changes
            ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            ");
            Console.Write("ENTER user choice(single char): ");
        }

        private void TestMain()
        {
            Employee emp1 = new SalariedEmployee("Dahyun", "Kim", "206-21-2218", "kimdah@uw.edu", 800.00M);
            Employee emp2 = new HourlyEmployee("Jihyo", "Park", "232-93-4997", "parkji@uw.edu", 25.75M, 40.00M);
            Employee emp3 = new CommissionEmployee("Jeongyeon", "Yoo", "124-18-1246", "yoojeong@uw.edu", 30000.00M, 0.06M);
            Employee emp4 = new BasePlusCommissionEmployee("Chaeyoung", "Son", "sonchae@uw.edu", "225-34-1299", 40000.00M, 0.09M, 10000.00M);
            Employee emp5 = new SalariedEmployee("Tzuyu", "Chou", "971-65-1949", "choutaz@uw.edu", 900.00M);
            Employee emp6 = new HourlyEmployee("Nayeon", "Im", "852-21-2245", "imqueen@uw.edu", 25.25M, 40.00M);
            Employee emp7 = new CommissionEmployee("Momo", "Hira", "206-66-8796", "momo@uw.edu", 50000.00M, 0.06M);
            Employee emp8 = new BasePlusCommissionEmployee("Sana", "Minatozaki", "157-78-2216", "shyshy@uw.edu", 60000.00M, 0.06M, 15000.00M);

            employees.Add(emp1);
            employees.Add(emp2);
            employees.Add(emp3);
            employees.Add(emp4);
            employees.Add(emp5);
            employees.Add(emp6);
            employees.Add(emp7);
            employees.Add(emp8);
        }   
    }
}