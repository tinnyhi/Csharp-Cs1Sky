﻿///////////////////////////////
// Tin Tin Chien, Cynthia Gu
// TNFO-200 A - C# Program 
// 2023-02-26 
///////////////////////////////////
// This is an Employee Database
// Where the user can find, create, update, delete, print and quit from the data base


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//////////////////////////////////////////////
//Change History 
//Date              Developer       Description
//2023-02-26        Cs323           initial creation    
//2023-02-27        Cs323           finished rest of Employee classes and worked more on EmpDB
//2023-03-02        Cs323           Tried to determine the problem if not being run program
//2023-03-03        Cs323           Have figured out problem with instructor and able to run program 
                                    // Adding more descriptive comments in program  and initial testing

namespace Cs3emp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            EmployeeDB app = new EmployeeDB();
            app.GoDatabase();
        }
    }
}
