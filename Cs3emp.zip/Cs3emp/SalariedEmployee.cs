﻿///////////////////////////////
// Tin Tin Chien, Cynthia Gu
// TNFO-200 A - C# Program 
// 2023-02-26 
///////////////////////////////////
// This is an Employee Database
// Where the user can find, create, update, delete, print and quit from the data base

using Cs3emp;
using System;

namespace Cs3emp
{
    public class SalariedEmployee : Employee
    {
        private decimal weeklySalary;

        // four-parameter constrcutor
        public SalariedEmployee(string firstName, string lastName,
            string socialSecurityNumber, string emailAddress, decimal weeklySalary)
            : base(firstName, lastName, socialSecurityNumber, emailAddress)
        {
            WeeklySalary = weeklySalary;
        }

        public decimal WeeklySalary
        {
            get
            {
                return weeklySalary;
            }
            set
            {
                if (value < 0) // validation
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
                       value, $"{nameof(WeeklySalary)} must be >= 0");
                }

                weeklySalary = value;
            }
        }

        public SalariedEmployee()
        {

        }

        // calculate earnings; override abstract method Earnings in Employee
        public override decimal Earnings() => WeeklySalary;

        // return string representation of SalariedEmployee object
        public override string ToString()
        {
            return base.ToString() + $"Salary: {WeeklySalary:C}";
        }

    }
}