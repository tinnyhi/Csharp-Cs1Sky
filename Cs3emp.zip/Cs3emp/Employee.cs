﻿///////////////////////////////
// Tin Tin Chien, Cynthia Gu
// TNFO-200 A - C# Program 
// 2023-02-26 
///////////////////////////////////
// This is an Employee Database
// Where the user can find, create, update, delete, print and quit from the data base


namespace Cs3emp
{
    public abstract class Employee
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string SocialSecurityNumber { get; set; }
        public string EmailAddress { get; set; }

        // fully specified ctor
        public Employee (string firstName, string lastName, string socialSecurityNumber, string emailAddress)
        {
            FirstName = firstName;
            LastName = lastName;
            SocialSecurityNumber = socialSecurityNumber;
            EmailAddress = emailAddress;
        }

        public Employee()
        {

        }


        public virtual string ToStringForDataFile()
        {
            string str = $"{FirstName}\n";
            str += $"{LastName}\n";
            str += $"{SocialSecurityNumber}\n";
            str += $"{EmailAddress}\n";
            return str;
        }

        public override string ToString()
        {
            string str = "*******************************\n";
            str += $"First: {FirstName}\n";
            str += $" Last: {LastName}\n";
            str += $"  SSN: {SocialSecurityNumber}\n";
            str += $"Email: {EmailAddress}\n";
            return str;
        }

        public abstract decimal Earnings();
    }
}