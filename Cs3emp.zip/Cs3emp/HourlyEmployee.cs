﻿///////////////////////////////
// Tin Tin Chien, Cynthia Gu
// TNFO-200 A - C# Program 
// 2023-02-26 
///////////////////////////////////
// This is an Employee Database
// Where the user can find, create, update, delete, print and quit from the data base


using System;

namespace Cs3emp
{
    public class HourlyEmployee : Employee
    {
        private decimal wage; // wage per hour
        private decimal hours; // hours worked for the week

        // five-parameter constructor
        public HourlyEmployee (string firstName, string lastName, 
            string socialSecruityNumber, string email, 
            decimal hourlyWage, decimal hoursWorked)
            : base(firstName, lastName, socialSecruityNumber, email)   
        {
            Wage = hourlyWage;
            hours = hoursWorked;
        }

        public HourlyEmployee()
        {

        }

        // property that gets and sets hourly Employee's wage
        public decimal Wage
        {
            get
            {
                return wage;
            }
            set
            {
                if (value < 0) // validation
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
                       value, $"{nameof(Wage)} must be >= 0");
                }

                wage = value;
            }
        }

        // property that gets and sets hourly employee's hours
        public decimal Hours
        {
            get
            {
                return hours;
            }
            set
            {
                if (value < 0 || value > 168) // validation
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
                       value, $"{nameof(Hours)} must be >= 0 and <= 168");
                }

                hours = value;
            }
        }

        // calculate earnings; override Employee’s abstract method Earnings
        public override decimal Earnings()
        {
            if (Hours <= 40) // no overtime                          
            {
                return Wage * Hours;
            }
            else
            {
                return (40 * Wage) + ((Hours - 40) * Wage * 1.5M);
            }
        }

        public override string ToString()
        {
            return base.ToString() + $" Wage: {Wage:C}\nHours: {Hours:F2}";

        }

    }
}