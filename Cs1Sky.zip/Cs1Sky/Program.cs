﻿////////////////////////////////////////////////////////////
/// Cynthia Gu, Justin Doan, Larry Bui, Tin Tin Chien
/// TINFO-200 A - C# Programming
/// 1-18-2023
////////////////////////////////////////////////////////////
/// SkyTour Inc. Helicopter Tours of Mt. Rainer
/// A program that processes passengers' information for the helicopter tour of Mt.Rainer


using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

///////////////////////////////////////
// Change History
//Date           Developer       Description
//2023-01-18     Team 22         Initial creation and coding of the solution
//2023-01-18     Team 22         Initial testing

namespace Cs1Sky
{
    // This ???
    // This program is where the main entry point of the program is located.
    // This will also be where the input data is obtained from the users and the output information is printed.
    // Every class file in C# needs a logical description.
    internal class Program
    {
        static void Main(string[] args)
        {
            //All programs must have a UI that does 2 things:
            // 1 - tell the user why they would want to use the applications
            // 2 - help the user, or tell them how to use the software
            // using a C# verbatim string
            Console.WriteLine(@"
********************************************
************ SKYTRIP RESERVATION *************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This is a simple program that can calculate
passenger's information and confirm passengers
data for the SkyTrip helicopter tour.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
");




            ///////////////////////////////////////////////////////////////////////////
            // Input Section-
            // Get data from the user for the information and numbers we need to??????
            // Get their first name
            Console.WriteLine("Enter in your first name: ");
            //caputre the first name that the user input for their first name
            string firstName = Console.ReadLine();


            //Get their last name
            Console.WriteLine("Enter in your last name: ");
            //capture the last name that the user input for their last name
            string lastName = Console.ReadLine();

            //Get passenger's age
            Console.WriteLine("Enter your age: ");
            int passAge = int.Parse(Console.ReadLine());

            //Get passenger's weight
            Console.WriteLine("Enter your weight, " + "limited to a single decimal point in lbs [ex: 220.5 lbs]: ");
            double passWeight = double.Parse(Console.ReadLine());

            //Get date and time at the current time of the purchase
            string passTime = DateTime.Now.ToString();

            
            
            

            ///////////////////////////////////////////////////////////////////////////
            // Processing Section - 
            // Take user weight data and formulate some math calculations to convert lbs into kilos
            // Calculate passengers' total weight
            double kg = passWeight / 2.2045;
            double totalWeight = passWeight;
            decimal finalWeight = Math.Round((decimal)kg, 1);
            decimal price = 1 * finalWeight;
            


            ///////////////////////////////////////////////////////////////////////////
            // Output Section - 
            // Take the info that the user inputed and present it to the user.
            // Take the lbs that was calculated and converted to kgs and present it to the user.
            // Total weight of all passengers
            Console.WriteLine($"Passenger Name: {firstName} {lastName}");
            Console.WriteLine($"Passenger Age: {passAge}");
            Console.WriteLine($"Weight: {passWeight} lb, {finalWeight} kg, {price:C}");
            Console.WriteLine($"Report Timestamp: {passTime}");

            
            

        }
    }
}
